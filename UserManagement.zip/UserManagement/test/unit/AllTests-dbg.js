sap.ui.define([
	"inhance/userManagementSecurity/test/unit/controller/app.controller"
], function () {
	"use strict";
});